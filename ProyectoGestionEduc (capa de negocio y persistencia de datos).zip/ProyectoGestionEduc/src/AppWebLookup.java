public interface AppWebLookup {
}