public interface AppEscritorioLookup {
}