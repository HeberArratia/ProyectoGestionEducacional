package Diagramarefinado.Reporte;

public class Reporte {

	public void obtenerBalanceIngGasto() {
		// TODO - implement Reporte.obtenerBalanceIngGasto
		throw new UnsupportedOperationException();
	}

}