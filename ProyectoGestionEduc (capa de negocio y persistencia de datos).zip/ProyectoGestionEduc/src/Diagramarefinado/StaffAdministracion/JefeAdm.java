package Diagramarefinado.StaffAdministracion;

import Diagramarefinado.Persona.*;

public class JefeAdm extends Persona {
	

	public JefeAdm(String nombre, String apellido, String rut) {
		super(nombre, apellido, rut);
		// TODO Auto-generated constructor stub
	}

	public void ingresarPagoSueldo() {
		// TODO - implement JefeAdm.ingresarPagoSueldo
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param NuevaPer
	 */
	public void agregarNuevoJefeAdm(Persona NuevaPer) {
		// TODO - implement JefeAdm.agregarNuevoJefeAdm
		throw new UnsupportedOperationException();
	}

}