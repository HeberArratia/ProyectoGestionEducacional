package Diagramarefinado.StaffAdministracion;

import Diagramarefinado.Persona.*;

public class Director extends Persona {

	public Director(String nombre, String apellido, String rut) {
		super(nombre, apellido, rut);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 * @param NuevaPer
	 */
	public void agregarNuevoDirector(Persona NuevaPer) {
		// TODO - implement Director.agregarNuevoDirector
		throw new UnsupportedOperationException();
	}

}