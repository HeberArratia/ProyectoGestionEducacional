package Diagramarefinado.Finanza;

public class Mensualidad {

	public void regPagoMensualidad() {
		// TODO - implement Mensualidad.regPagoMensualidad
		throw new UnsupportedOperationException();
	}

	public void obtenerListMorososMensualidad() {
		// TODO - implement Mensualidad.obtenerListMorososMensualidad
		throw new UnsupportedOperationException();
	}

}