package Diagramarefinado.Finanza;

public class Sueldo {

	public void obtenerListSueldoProf() {
		// TODO - implement Sueldo.obtenerListSueldoProf
		throw new UnsupportedOperationException();
	}

}