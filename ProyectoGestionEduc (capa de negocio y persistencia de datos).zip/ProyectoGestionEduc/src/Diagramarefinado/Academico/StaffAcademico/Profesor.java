package Diagramarefinado.Academico.StaffAcademico;

import Diagramarefinado.Persona.*;

public class Profesor extends Persona {
	
	public Profesor(String nombre, String apellido, String rut) {
		super(nombre, apellido, rut);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 * @param NuevaPer
	 */
	public void agregarNuevoProfesor(Persona NuevaPer) {
		// TODO - implement Profesor.agregarNuevoProfesor
		throw new UnsupportedOperationException();
	}

	public void buscarProfesor() {
		// TODO - implement Profesor.buscarProfesor
		throw new UnsupportedOperationException();
	}

}