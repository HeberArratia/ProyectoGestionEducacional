package Diagramarefinado.Academico;

public class Curso {

	public void desactivarCurso() {
		// TODO - implement Curso.desactivarCurso
		throw new UnsupportedOperationException();
	}

	public void crearCurso() {
		// TODO - implement Curso.crearCurso
		throw new UnsupportedOperationException();
	}

}