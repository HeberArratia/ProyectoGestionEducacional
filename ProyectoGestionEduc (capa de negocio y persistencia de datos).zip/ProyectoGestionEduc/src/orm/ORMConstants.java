/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: Universidad de La Frontera
 * License Type: Academic
 */
package orm;

public interface ORMConstants extends org.orm.util.ORMBaseConstants {
	final int KEY_CURSO_CURSO_PROFESOR = -366482352;
	
	final int KEY_CURSO_DIRECTOR = 1856847855;
	
	final int KEY_CURSO_ESTUDIANTE_CURSO = 1381893458;
	
	final int KEY_CURSO_PROFESOR_CURSO = 2002294826;
	
	final int KEY_CURSO_PROFESOR_PROFESOR = 280464284;
	
	final int KEY_DIRECTOR_CURSO = -430593463;
	
	final int KEY_DIRECTOR_PERSONA = 1006092825;
	
	final int KEY_ESTUDIANTE_CURSO_CURSO = -1585165204;
	
	final int KEY_ESTUDIANTE_CURSO_ESTUDIANTE = 106923010;
	
	final int KEY_ESTUDIANTE_ESTUDIANTE_CURSO = 623355548;
	
	final int KEY_ESTUDIANTE_MATRICULA = -344556687;
	
	final int KEY_ESTUDIANTE_MENSUALIDAD = 504542996;
	
	final int KEY_ESTUDIANTE_PERSONA = 106704479;
	
	final int KEY_JEFEADMINISTRACION_PERSONA = -623015594;
	
	final int KEY_JEFEADMINISTRACION_SUELDO_PROFESOR = 526101663;
	
	final int KEY_MATRICULA_ESTUDIANTE = -871448749;
	
	final int KEY_MATRICULA_SECRETARIA = -1979836102;
	
	final int KEY_MENSUALIDAD_ESTUDIANTE = -1923760368;
	
	final int KEY_MENSUALIDAD_SECRETARIA = 1262819575;
	
	final int KEY_PERSONA_DIRECTOR = -1628120353;
	
	final int KEY_PERSONA_ESTUDIANTE = -1822888859;
	
	final int KEY_PERSONA_JEFEADMINISTRACION = -232780964;
	
	final int KEY_PERSONA_PROFESOR = 1418427709;
	
	final int KEY_PERSONA_SECRETARIA = 1363691084;
	
	final int KEY_PROFESOR_CURSO_PROFESOR = 1856083202;
	
	final int KEY_PROFESOR_PERSONA = -1158863241;
	
	final int KEY_PROFESOR_SUELDO_PROFESOR = -1789880128;
	
	final int KEY_SECRETARIA_MATRICULA = 656924824;
	
	final int KEY_SECRETARIA_MENSUALIDAD = 855600763;
	
	final int KEY_SECRETARIA_PERSONA = -106778298;
	
	final int KEY_SUELDO_PROFESOR_JEFEADMINISTRACION = -2067169421;
	
	final int KEY_SUELDO_PROFESOR_PROFESOR = -58994156;
	
	final int KEY_SUELDO_PROFESOR_SUELDO = -778733698;
	
	final int KEY_SUELDO_SUELDO_PROFESOR = -852971606;
	
}
